package com.devproject.ownStyle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OwnStyleApplication {

	public static void main(String[] args) {
		SpringApplication.run(OwnStyleApplication.class, args);
	}

}
