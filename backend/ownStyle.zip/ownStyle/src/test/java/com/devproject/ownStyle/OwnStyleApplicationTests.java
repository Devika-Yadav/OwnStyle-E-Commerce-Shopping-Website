package com.devproject.ownStyle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OwnStyleApplicationTests {

	@Test
	void contextLoads() {
	}

}
